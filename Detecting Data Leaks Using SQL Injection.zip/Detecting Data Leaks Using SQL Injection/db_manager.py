import sqlite3
import hashlib
from encryption import AESCipher

DB_NAME = 'secure_data.db'

class SQLCapability:
    """
    A capability token that permits SQL execution.
    In a more complex system, this could verify the caller's identity or role.
    Here, it serves as a gatekeeper to ensure only authorized flows execute queries.
    """
    def __init__(self, authorized=False):
        self._authorized = authorized

    def is_authorized(self):
        return self._authorized

class SecureDBInterface:
    def __init__(self):
        self.cipher = AESCipher()
        self._init_db()

    def _get_conn(self):
        return sqlite3.connect(DB_NAME)

    def _init_db(self):
        conn = self._get_conn()
        cursor = conn.cursor()
        # Create Users Table
        # sensitive_data is stored as AES-256 encrypted string
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                sensitive_data TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def get_read_capability(self):
        """Grant a capability for reading data."""
        return SQLCapability(authorized=True)

    def get_write_capability(self):
        """Grant a capability for writing data."""
        return SQLCapability(authorized=True)

    def add_user(self, capability: SQLCapability, username, password, sensitive_info):
        """
        Securely adds a user.
        - Hashes password.
        - Encrypts sensitive info (AES-256).
        - Uses parameterized queries (SQL Injection prevention).
        """
        if not capability.is_authorized():
            raise PermissionError("Unauthorized: Missing Write Capability")

        password_hash = hashlib.sha256(password.encode()).hexdigest()
        encrypted_info = self.cipher.encrypt(sensitive_info)

        conn = self._get_conn()
        cursor = conn.cursor()
        try:
            # Layer 2 Security: Parameterized Query
            cursor.execute('INSERT INTO users (username, password_hash, sensitive_data) VALUES (?, ?, ?)',
                           (username, password_hash, encrypted_info))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    def verify_user(self, capability: SQLCapability, username, password):
        """
        Verifies user credentials.
        """
        if not capability.is_authorized():
            raise PermissionError("Unauthorized: Missing Read Capability")

        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = self._get_conn()
        cursor = conn.cursor()
        # Layer 2 Security: Parameterized Query
        cursor.execute('SELECT id FROM users WHERE username = ? AND password_hash = ?', (username, password_hash))
        user = cursor.fetchone()
        conn.close()
        return user is not None

    def get_user_data(self, capability: SQLCapability, username):
        """
        Retrieves and decrypts user data.
        """
        if not capability.is_authorized():
            raise PermissionError("Unauthorized: Missing Read Capability")

        conn = self._get_conn()
        cursor = conn.cursor()
        # Layer 2 Security: Parameterized Query
        cursor.execute('SELECT sensitive_data FROM users WHERE username = ?', (username,))
        row = cursor.fetchone()
        conn.close()

        if row:
            encrypted_data = row[0]
            return self.cipher.decrypt(encrypted_data)
        return None

    def search_users_unsafe_demo(self, query_str):
        """
        VULNERABLE FUNCTION - FOR DEMONSTRATION ONLY.
        This represents what we are preventing.
        """
        conn = self._get_conn()
        cursor = conn.cursor()
        sql = f"SELECT * FROM users WHERE username = '{query_str}'"
        print(f"Executing Unsafe SQL: {sql}")
        try:
            cursor.executescript(sql) # Using executescript to allow multiple statements for demo
            return "Executed"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

