import unittest
import os
from db_manager import SecureDBInterface, SQLCapability
from encryption import AESCipher

class TestSecuritySystem(unittest.TestCase):
    def setUp(self):
        # Use a fresh DB for testing if possible, or just use the main one carefully
        self.db = SecureDBInterface()
        self.test_user = "testuser" + os.urandom(4).hex()
        self.test_pass = "password123"
        self.test_data = "This is a secret message."

    def test_encryption(self):
        cipher = AESCipher()
        encrypted = cipher.encrypt(self.test_data)
        decrypted = cipher.decrypt(encrypted)
        self.assertEqual(self.test_data, decrypted)
        print("[PASS] Encryption/Decryption verified.")

    def test_secure_storage(self):
        # Test Registration
        cap = self.db.get_write_capability()
        success = self.db.add_user(cap, self.test_user, self.test_pass, self.test_data)
        self.assertTrue(success)
        print(f"[PASS] User '{self.test_user}' registered securely.")

        # Test Login
        read_cap = self.db.get_read_capability()
        login_success = self.db.verify_user(read_cap, self.test_user, self.test_pass)
        self.assertTrue(login_success)
        print("[PASS] User login verified.")

        # Test Data Retrieval
        retrieved_data = self.db.get_user_data(read_cap, self.test_user)
        self.assertEqual(self.test_data, retrieved_data)
        print("[PASS] Sensitive data retrieved and decrypted correctly.")

    def test_sql_injection_prevention(self):
        # Try to register a user with a SQL injection payload as username
        # This bypasses Layer 1 (Flask) but tests Layer 2 (DB Manager)
        
        malicious_user = "hacker' OR '1'='1"
        cap = self.db.get_write_capability()
        
        # Even if we pass this to add_user, the parameterized query should treat it as a literal string
        # It shouldn't break the SQL syntax.
        success = self.db.add_user(cap, malicious_user, "pass", "secret")
        
        # If successful, it means it was added as a literal username "hacker' OR '1'='1"
        # If it failed with a syntax error (which we can't easily catch inside except verifying the DB state), it would be bad.
        # But here add_user returns True/False based on IntegrityError (duplicate).
        # We just want to ensure it doesn't execute the injection.
        
        conn = self.db._get_conn()
        cursor = conn.cursor()
        cursor.execute("SELECT count(*) FROM users WHERE username = ?", (malicious_user,))
        count = cursor.fetchone()[0]
        conn.close()
        
        if success:
             self.assertEqual(count, 1)
             print("[PASS] SQL Injection payload was treated as literal string (Safe).")
        else:
             # If it failed, it might be due to duplicate if run twice
             pass

    def test_capability_enforcement(self):
        # Try to call methods without capability
        class FakeCap:
            def is_authorized(self):
                return False
        
        with self.assertRaises(PermissionError):
            self.db.get_user_data(FakeCap(), self.test_user)
        print("[PASS] Capability mechanism enforced.")

if __name__ == '__main__':
    unittest.main()
