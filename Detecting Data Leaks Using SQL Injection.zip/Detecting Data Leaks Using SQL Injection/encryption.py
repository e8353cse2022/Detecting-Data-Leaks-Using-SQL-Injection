import os
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

# AES-256 requires a 32-byte key
KEY_FILE = 'aes_key.bin'

def get_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as f:
            key = f.read()
    else:
        key = os.urandom(32)  # 256 bits
        with open(KEY_FILE, 'wb') as f:
            f.write(key)
    return key

class AESCipher:
    def __init__(self):
        self.key = get_key()
        self.backend = default_backend()

    def encrypt(self, raw_data):
        if raw_data is None:
            return None
        if not isinstance(raw_data, bytes):
            raw_data = raw_data.encode('utf-8')

        # Generate a random IV (Initialization Vector) - 16 bytes for AES
        iv = os.urandom(16)
        
        # AES-256 in CBC mode (Requires padding)
        cipher = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend)
        encryptor = cipher.encryptor()
        
        # Pad the data to be a multiple of block size (128 bits / 16 bytes)
        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(raw_data) + padder.finalize()
        
        encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
        
        # Return IV + Encrypted Data encoded in base64 for storage
        return base64.b64encode(iv + encrypted_data).decode('utf-8')

    def decrypt(self, enc_data):
        if enc_data is None:
            return None
        
        try:
            enc_data_bytes = base64.b64decode(enc_data)
            
            # Extract IV (first 16 bytes)
            iv = enc_data_bytes[:16]
            ciphertext = enc_data_bytes[16:]
            
            cipher = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend)
            decryptor = cipher.decryptor()
            
            padded_data = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Unpad data
            unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
            data = unpadder.update(padded_data) + unpadder.finalize()
            
            return data.decode('utf-8')
        except Exception as e:
            print(f"Decryption error: {e}")
            return None

# Simple test
if __name__ == "__main__":
    aes = AESCipher()
    original = "Sensitive User Data"
    encrypted = aes.encrypt(original)
    print(f"Encrypted: {encrypted}")
    decrypted = aes.decrypt(encrypted)
    print(f"Decrypted: {decrypted}")
