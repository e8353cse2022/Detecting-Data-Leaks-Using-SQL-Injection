from flask import Flask, render_template, request, redirect, url_for, flash, session
from db_manager import SecureDBInterface
import re
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Secure secret key for session signing

# Initialize Secure DB Interface
db = SecureDBInterface()

# Layer 1 Security: Input Validation
def is_safe_input(input_str):
    """
    Validates input to ensure it only contains alphanumeric characters.
    This acts as the first line of defense (WAF-like).
    """
    if not input_str:
        return False
    return re.match("^[a-zA-Z0-9]+$", input_str) is not None

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Layer 1 Check
        if not is_safe_input(username):
            flash('Security Alert: Invalid characters detected in username.', 'error')
            return redirect(url_for('login'))

        try:
            # Acquire Read Capability
            read_cap = db.get_read_capability()
            
            # Layer 2 Check (Secure DB Access)
            if db.verify_user(read_cap, username, password):
                session['username'] = username
                flash('Login successful.', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid credentials.', 'error')
        except Exception as e:
            flash(f'System Error: {str(e)}', 'error')
            
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        sensitive_data = request.form['sensitive_data']

        # Layer 1 Check
        if not is_safe_input(username):
            flash('Security Alert: Username must be alphanumeric only.', 'error')
            return redirect(url_for('register'))

        if not password or not sensitive_data:
            flash('All fields are required.', 'error')
            return redirect(url_for('register'))

        try:
            # Acquire Write Capability
            write_cap = db.get_write_capability()
            
            # Layer 2 Check (Secure DB Access + Encryption)
            if db.add_user(write_cap, username, password, sensitive_data):
                flash('Registration successful! Your data is now encrypted.', 'success')
                return redirect(url_for('login'))
            else:
                flash('Username already exists.', 'error')
        except Exception as e:
            flash(f'Registration Error: {str(e)}', 'error')

    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    
    try:
        # Acquire Read Capability
        read_cap = db.get_read_capability()
        
        # Securely retrieve and decrypt data
        secret_data = db.get_user_data(read_cap, username)
        
        return render_template('dashboard.html', username=username, secret_data=secret_data)
    except Exception as e:
        flash(f'Access Error: {str(e)}', 'error')
        return redirect(url_for('logout'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out securely.', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
    # Running on 0.0.0.0 makes it accessible over the network
    app.run(debug=True, host='0.0.0.0', port=5000)
